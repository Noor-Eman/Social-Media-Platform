import postPic1 from '../img/PostImage/umesha.png'
import postPic2 from '../img/PostImage/skill3.jpeg'
import postPic3 from '../img/PostImage/us.jpg'


export const PostsData = [
    {
        img: postPic1,
        name: 'Tzuyu',
        desc: "Happy New Year all friends! #2023",
        likes: 2300,
        liked: true
    },
    {
        img: postPic2,
        name: 'Maryam',
        desc: "Party time :)",
        likes: 2300,
        liked: false

    },
    {
        img:postPic3,
        name: "Salena Gomez",
        desc: "At Archery Festival",
        likes: 800,
        liked: false
    }
]